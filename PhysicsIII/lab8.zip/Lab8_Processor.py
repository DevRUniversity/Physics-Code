import math
import matplotlib.pyplot as p1
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np                # import numpy
from scipy import optimize
import random
def average_of_list(list):
    return sum(list)/len(list)

def gaus(x,A,x0,sigma):
  temp = (x-x0)**2
  temp = temp/(2*sigma**2)
  return A * np.exp(-temp)

def gauss_fit_on_list(xData,yData):       
    parameters,  covariance = optimize.curve_fit(
        gaus,xdata=xData,ydata=yData,p0=[100,xData[0],100]) #covariance is only there because of python return
    #covariance matrix will throw a bug, told this was irrelevant in this case
    return parameters

#https://www.geeksforgeeks.org/python-program-for-binary-search/
def binary_search(arr, x):
    low = 0
    high = len(arr) - 1
    mid = 0
 
    while low <= high:
 
        mid = (high + low) // 2
 
        # If x is greater, ignore left half
        if arr[mid] < x:
            low = mid + 1
 
        # If x is smaller, ignore right half
        elif arr[mid] > x:
            high = mid - 1
 
        # means x is present at mid
        else:
            return mid
 
    # If we reach here, then the element was not present
    return -1



time_values = []
port = 'COM4' # windows like port information

volt_equivalent_values = []
radius_turned_values = []
time_values = []
time_real = 0
max_volt_equivalent = -100000
min_volt_equivalent = 100000
StepsPerRevolution = 2038
sensitivity = 1.4 #higher is less sensative

File_object = open(r"Lab8Data.txt", "r")
error_processing_counter = 0
for line in File_object:
    message = line     # read data from the serial port
    if(len(message) > 0):
        message = message.strip()    # strip here means remove all whit charaters, new lines and carriage returns from the string.
        volt_equivalent,time,radius_counter_turned = message.split(':') # split the string at a colon, making two strings stored in time, value
        error_processing_counter = error_processing_counter + 1
        print(str(volt_equivalent) +":::" + str(time) + ":::" + str(radius_counter_turned) + " LINE: " + str(error_processing_counter))  # print the first number
       # print(time) # print the second number
        time_real = int(time)
        time_values.append(int(time))
        radius_turned_values.append(float(radius_counter_turned))
        volt_equivalent_values.append(int(volt_equivalent))
        if(int(volt_equivalent) > max_volt_equivalent): #just finds the largest 'volt' equivalent
            max_volt_equivalent = int(volt_equivalent)
        if(int(volt_equivalent) < min_volt_equivalent):
            min_volt_equivalent = int(volt_equivalent)

File_object.close()
        



xData =[]
for i in radius_turned_values:
    xData.append(i)


avg = average_of_list(volt_equivalent_values)
xData2 = []
yData2 = []
max_value_on_range = []
max_value_on_range.append(0)
max_value = 0
#need to run it one time first to get the sorted xData2copy list. 
for i in range(0,len(volt_equivalent_values)):
    if(volt_equivalent_values[i] > avg*sensitivity): #lowered sensitivity to be just greater than the average times 1.09
        xData2.append(radius_turned_values[i])
        yData2.append(volt_equivalent_values[i])



partitions_left_bounds = []
partitions_right_bounds = []
radius_turned_copied_reduced = radius_turned_values.copy()
radius_turned_copied_reduced = [*set(radius_turned_copied_reduced)]
radius_turned_copied_reduced.sort() #I could probably write something with a better time complexity than a base form (unless its very optimized, but if I recall right it is not) However our data set is low enough I don't care about the time complexity
xData2copy = xData2.copy()
xData2copy = [*set(xData2copy)]
xData2copy.sort() #I could probably write something with a better time complexity than a base form (unless its very optimized, but if I recall right it is not) However our data set is low enough I don't care about the time complexity

in_bounds = False
"""
This segment of code is just meant to find reasonable left and right bounds for searching for a maximum, there is probably a way to do this better, but its working so it doesn't really matter
"""
for i in range(1,len(radius_turned_copied_reduced)):
    if(binary_search(xData2copy, radius_turned_copied_reduced[i]) != -1 and binary_search(xData2copy, radius_turned_copied_reduced[i-1]) != -1):
        if(in_bounds == False):
            partitions_left_bounds.append(radius_turned_copied_reduced[i])
        in_bounds = True
    else:
        if(in_bounds == True):
            partitions_right_bounds.append(radius_turned_copied_reduced[i])
            in_bounds = False

"""
This statistical variant is a remnant from an attempt to do things better, specifically to remove noise from the data. However, this became unnessecary so it was repurposed to remove noise from just finding the maximums since that was all we actually needed
"""
volt_equivalent_values_statistical = [0]*len(radius_turned_copied_reduced) #creates list of 0s of length equal to radius turned copied reduced
for i in range (0,len(radius_turned_copied_reduced)):
    temp_counter_for_volt_equivalent = 0
    for j in range(0,len(volt_equivalent_values)):
        if(radius_turned_values[j] == radius_turned_copied_reduced[i]): #radius turned counter has the same len as volt_equivalent values
            temp_counter_for_volt_equivalent = temp_counter_for_volt_equivalent+ 1
            if( volt_equivalent_values_statistical[i] < volt_equivalent_values[j]):
                volt_equivalent_values_statistical[i] = volt_equivalent_values[j] #+ volt_equivalent_values_statistical[i]
    
print(partitions_left_bounds)
print(partitions_right_bounds)

list_of_max_values_indices = []
in_bounds = False
max_value_voltage = -10000
for i in range(0,len(radius_turned_copied_reduced)):
    if(binary_search(partitions_left_bounds, radius_turned_copied_reduced[i]) != -1):
        in_bounds = True
        max_value = -10000
        max_value_voltage = -10000
    if(in_bounds == True):
        if(volt_equivalent_values_statistical[i] > max_value_voltage):
            max_value_voltage = volt_equivalent_values_statistical[i]
            max_value = radius_turned_copied_reduced[i]
    if(binary_search(partitions_right_bounds, radius_turned_copied_reduced[i]) != -1):
        list_of_max_values_indices.append(max_value)
        in_bounds = False

print(list_of_max_values_indices)

max_diff = -100000
min_diff = 100000
list_of_diffs = []
for i in range(1,len(list_of_max_values_indices)):
    diff = abs(list_of_max_values_indices[i] - list_of_max_values_indices[i-1])
    if(diff > max_diff):
        max_diff = diff
    if(diff < min_diff):
        min_diff = diff
    list_of_diffs.append(diff)
print("Min Diff: " + str(min_diff) + " Max Diff: " + str(max_diff) + " Average Diff: " + str(average_of_list(list_of_diffs)))



"""
Wavelength Calculations
"""

length_geo = 0.0545 #0.05781
radius_geo = 0.0531 #0.05620
d_grating = (1/1000)/300
corrective_shift = 13 #if positive, 0 peak is to the right, if negative 0 peak is to the left
theta_values = []
temp_counter = 0
for m in range(1,5):
    for counter_value in list_of_max_values_indices:
        phi = ((counter_value-corrective_shift)/StepsPerRevolution)*2*math.pi
        theta = np.arctan((radius_geo * math.sin(phi))/(radius_geo*math.cos(phi) + length_geo))
        theta_values.append(theta)
        #print(theta)
        lambda_wavelength = d_grating * math.sin(abs(theta))/(m)
        temp_counter = temp_counter + 1
        print("Lambda/Wavelength = "  + str(lambda_wavelength*((10)**9))[0:7] + " nanometers")
    print("=========================BREAK=========================           m = " + str(m))
 













plt.scatter(xData,volt_equivalent_values, color = "BLUE", label = "Experimental Value", s = 0.3)
plt.scatter(xData2,yData2, color = "RED", label = "Experimental Value", s = 0.3)
max_points_x_display = []
max_points_y_display = []
for i in list_of_max_values_indices:
    for j in range(min_volt_equivalent,max_volt_equivalent):
        max_points_x_display.append(i)
        max_points_y_display.append(j)
    plt.scatter(max_points_x_display,max_points_y_display, color = "ORANGE", s = 0.1)
orange_patch = mpatches.Patch(color='orange', label='Counter offsets with a maximum')
red_intensity_patch = mpatches.Patch(color='red', label= 'Intensity Values detected by software as notable')
blue_intensity_patch = mpatches.Patch(color='blue', label='Equivalent Intensity Values')
plt.legend(handles=[orange_patch,red_intensity_patch,blue_intensity_patch],bbox_to_anchor=(1/3, 1))
plt.xlabel("Stepper Motor Counts from starting position")
plt.ylabel("Volt Equivalent Values from Photoresistor (measure of intensity)")
plt.show()































# adjusted_max_volt_equiv = max_volt_equivalent + 20
# for i in range(0,len(volt_equivalent_values)):
#     volt_equivalent_values[i] = adjusted_max_volt_equiv - volt_equivalent_values[i]
# print(len(time_values))
# print(len(volt_equivalent_values))

# mean = 0
# for i in volt_equivalent_values:
#     mean = mean + i
# mean = mean / len(volt_equivalent_values)

# period_points_time = []
# period_points_volt_equivalent = []

# period_time_intervals = []
# period_time_beginings = []
# array_of_arrays_of_period_hits_volt_equivalent = []
# array = []
# array_x_time_values = []
# gaus_fits = []
# for i in range(0,len(time_values)):
#     if volt_equivalent_values[i] > mean*2:   
#         period_points_time.append(time_values[i])
#         period_points_volt_equivalent.append(volt_equivalent_values[i])
#         if(len(array)==0):
#             for j in range(i-10,i):
#                 array.append(volt_equivalent_values[j])
#                 array_x_time_values.append(time_values[j])
#         array.append(volt_equivalent_values[i])
#         array_x_time_values.append(time_values[i])
#     else: 
#         if(len(array)>0): #in other words, checking that we have just been at a peak value
#             for j in range(i,i+10):
#                 array.append(volt_equivalent_values[j])
#                 array_x_time_values.append(time_values[j])
#             #print(array)
#             array_of_arrays_of_period_hits_volt_equivalent.append(array.copy())
#             params=gauss_fit_on_list(array_x_time_values,array)
#             gaus_fits.append( params )
#             # _,ax=plt.subplots()
#             # ax.plot(array_x_time_values,array)
#             # ax.set_title(params)
#             #print(gauss_fit_on_list(array_x_time_values,array))
#             #print(gauss_fit_on_list(array_x_time_values,array)[1])
            
#         array = []
#         array_x_time_values = []
#     # if(if_statement_triggered == False and not(volt_equivalent_values[i] < mean / 1.3)):
#     #     end_time = time_values[i]
#     #     time_interval = end_time - start_time
#     #     period_time_beginings.append(start_time)
#     #     period_time_intervals.append(time_values)



# #print(mean,mean*2)
# #print(len(array_of_arrays_of_period_hits_volt_equivalent))

# #print(array_of_arrays_of_period_hits_volt_equivalent)
# x_0_array = []
# for gaus_fit_parameters in gaus_fits:
#     x_0_array.append(gaus_fit_parameters[1])

# print("time peaks:")
# print(x_0_array)
# time_in_millis = []
# max_differance = 0
# min_differance = 10000000
# for i in range(0,len(x_0_array)-1):
#     differance = int(x_0_array[i+1]) - int(x_0_array[i])
#     if(differance > max_differance):
#         max_differance = differance
#     if(differance < min_differance):
#         min_differance = differance
#     time_in_millis.append(differance)
    
# print(x_0_array)
# print("Average Half Period Time:" + str(average_of_list(time_in_millis)))
# print("done")
# print("max diff:" + str(max_differance) + "min diff:" + str(min_differance))
# Length_of_rod = 1.53
# time_in_seconds = average_of_list(time_in_millis) / 1000
# print(time_in_seconds)
# period = time_in_seconds * 2  
# result = Length_of_rod  / math.pow(period/(math.pi * 2),2) 
# print( "g = " + str(result) )
# p1.plot(time_values, volt_equivalent_values)
# p1.scatter(period_points_time, period_points_volt_equivalent, color = "RED", linewidth=0.2)
# p1.show()


# # print(period_time_beginings)
# # print(period_time_intervals)

  

# differances_TIMES = []
# for i in range(0,len(time_values)-1):
#     differances_TIMES.append(time_values[i+1] - time_values[i])
# rolls = differances_TIMES

      

# # for i in range(0,100000):
# #     DataSet.append(random.randrange(1,13) + random.randrange(1,13))

# DataSet = rolls
# max_value_in_data = 0
# for i in DataSet:
#     if (i > max_value_in_data):
#         max_value_in_data = i
# data = plt.hist(DataSet,bins=range(1,max_value_in_data+1,1),color='red',fill='red',alpha=.4)
# plt.show()
# # print(period_time_beginings)
# # print(period_time_intervals)



