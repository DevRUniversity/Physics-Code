import math
import matplotlib.pyplot as p1
import matplotlib.pyplot as plt
import numpy as np                # import numpy
from scipy import optimize
import random
def average_of_list(list):
    return sum(list)/len(list)

def gaus(x,A,x0,sigma):
  temp = (x-x0)**2
  temp = temp/(2*sigma**2)
  return A * np.exp(-temp)

def gauss_fit_on_list(xData,yData):       
    parameters,  covariance = optimize.curve_fit(gaus,xdata=xData,ydata=yData,p0=[100,xData[0],100]) #covariance is only there because of python return
    #covariance matrix will throw a bug, told this was irrelevant in this case
    return parameters

time_values = []
port = 'COM4' # windows like port information

volt_equivalent_values = []
time_values = []
time_real = 0
max_volt_equivalent = 0

File_object = open(r"Lab4Data.txt", "r")
for line in File_object:
    message = line     # read data from the serial port
    if(len(message) > 0):
        message = message.strip()    # strip here means remove all whit charaters, new lines and carriage returns from the string.
        volt_equivalent,time = message.split(':') # split the string at a colon, making two strings stored in time, value
        print(str(volt_equivalent) +":::" + str(time))  # print the first number
       # print(time) # print the second number
        time_real = int(time)

        time_values.append(int(time))
        volt_equivalent_values.append(int(volt_equivalent))
        if(int(volt_equivalent) > max_volt_equivalent): #just finds the largest 'volt' equivalent
            max_volt_equivalent = int(volt_equivalent)

File_object.close()
        









adjusted_max_volt_equiv = max_volt_equivalent + 20
for i in range(0,len(volt_equivalent_values)):
    volt_equivalent_values[i] = adjusted_max_volt_equiv - volt_equivalent_values[i]
print(len(time_values))
print(len(volt_equivalent_values))

mean = 0
for i in volt_equivalent_values:
    mean = mean + i
mean = mean / len(volt_equivalent_values)

period_points_time = []
period_points_volt_equivalent = []

period_time_intervals = []
period_time_beginings = []
array_of_arrays_of_period_hits_volt_equivalent = []
array = []
array_x_time_values = []
gaus_fits = []
for i in range(0,len(time_values)):
    if volt_equivalent_values[i] > mean*2:   
        period_points_time.append(time_values[i])
        period_points_volt_equivalent.append(volt_equivalent_values[i])
        if(len(array)==0):
            for j in range(i-10,i):
                array.append(volt_equivalent_values[j])
                array_x_time_values.append(time_values[j])
        array.append(volt_equivalent_values[i])
        array_x_time_values.append(time_values[i])
    else: 
        if(len(array)>0): #in other words, checking that we have just been at a peak value
            for j in range(i,i+10):
                array.append(volt_equivalent_values[j])
                array_x_time_values.append(time_values[j])
            #print(array)
            array_of_arrays_of_period_hits_volt_equivalent.append(array.copy())
            params=gauss_fit_on_list(array_x_time_values,array)
            gaus_fits.append( params )
            # _,ax=plt.subplots()
            # ax.plot(array_x_time_values,array)
            # ax.set_title(params)
            #print(gauss_fit_on_list(array_x_time_values,array))
            #print(gauss_fit_on_list(array_x_time_values,array)[1])
            
        array = []
        array_x_time_values = []
    # if(if_statement_triggered == False and not(volt_equivalent_values[i] < mean / 1.3)):
    #     end_time = time_values[i]
    #     time_interval = end_time - start_time
    #     period_time_beginings.append(start_time)
    #     period_time_intervals.append(time_values)



#print(mean,mean*2)
#print(len(array_of_arrays_of_period_hits_volt_equivalent))

#print(array_of_arrays_of_period_hits_volt_equivalent)
x_0_array = []
for gaus_fit_parameters in gaus_fits:
    x_0_array.append(gaus_fit_parameters[1])

print("time peaks:")
print(x_0_array)
time_in_millis = []
for i in range(0,len(x_0_array)-1):
    time_in_millis.append(int(x_0_array[i+1]) - int(x_0_array[i]))
    print("DIFERANCE: " +str(int(x_0_array[i+1]) - int(x_0_array[i])))

print(x_0_array)
print("Average Half Period Time:" + str(average_of_list(time_in_millis)))
print("done")
Length_of_rod = 1.53
time_in_seconds = average_of_list(time_in_millis) / 1000
print(time_in_seconds)
period = time_in_seconds * 2  
result = Length_of_rod  / math.pow(period/(math.pi * 2),2) 
print( "g = " + str(result) )
p1.plot(time_values, volt_equivalent_values)
p1.scatter(period_points_time, period_points_volt_equivalent, color = "RED", linewidth=0.2)
p1.show()


# print(period_time_beginings)
# print(period_time_intervals)



