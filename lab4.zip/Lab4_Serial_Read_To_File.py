
import serial
import matplotlib.pyplot as p1
import matplotlib.pyplot as plt
import numpy as np                # import numpy
from scipy import optimize
import random

# def gaus(x,A,x0,sigma):
#   temp = (x-x0)**2
#   temp = temp/(2*sigma**2)
#   return A * np.exp(-temp)

# def gauss_fit_on_list(LIST):
#     DataSet = LIST
#     max_value_in_data = 0
#     for i in DataSet:
#         if (i > max_value_in_data):
#             max_value_in_data = i
#     data = plt.hist(DataSet,bins=range(1,max_value_in_data+1,1),color='red',fill='red',alpha=.4)
#     bins = np.linspace(1,max_value_in_data,max_value_in_data)
#     # finds the median betwleen # 
#     bincenters = np.array([0.5 * (bins[i] + bins[i+1]) for i in range(len(bins)-1)])
#     parameters,  covariance = optimize.curve_fit(gaus,xdata=bincenters,ydata= data[0],p0=[6,6,1]) #covariance is only there because of python return
#     return parameters

time_values = []
print(serial.__version__)
#port = '/dev/cu.usbmodem14401'  # mac like port information
port = 'COM4' # windows like port information
ser = serial.Serial(port, 9600, timeout=1)

volt_equivalent_values = []
time_values = []
time_real = 0
max_volt_equivalent = 0
File_object = open(r"Lab4Data.txt", "w+")

while(time_real < 15000):
    message = ser.readline()     # read data from the serial port
    if(len(message) > 0):
        message = message.decode()   # decode here means convert from byte array to string
        message = message.strip()    # strip here means remove all whit charaters, new lines and carriage returns from the string.
        File_object.write(message + '\n')
        volt_equivalent,time = message.split(':') # split the string at a colon, making two strings stored in time, value
        print(str(volt_equivalent) +":::" + str(time))  # print the first number
        time_real = int(time)

    #     time_values.append(int(time))
    #     volt_equivalent_values.append(int(volt_equivalent))
    #     if(int(volt_equivalent) > max_volt_equivalent):
    #         max_volt_equivalent = int(volt_equivalent)

File_object.close()
        









# adjusted_max_volt_equiv = max_volt_equivalent + 20
# for i in range(0,len(volt_equivalent_values)):
#     volt_equivalent_values[i] = adjusted_max_volt_equiv - volt_equivalent_values[i]
# print(len(time_values))
# print(len(volt_equivalent_values))
# ser.close()

# mean = 0
# for i in volt_equivalent_values:
#     mean = mean + i
# mean = mean / len(volt_equivalent_values)

# period_points_time = []
# period_points_volt_equivalent = []

# period_time_intervals = []
# period_time_beginings = []
# array_of_arrays_of_period_hits_volt_equivalent = []
# array = []









# for i in range(0,len(time_values)):
#     if volt_equivalent_values[i] > mean*2:   
#         period_points_time.append(time_values[i])
#         period_points_volt_equivalent.append(volt_equivalent_values[i])
#         if(len(array)==0):
#             for j in range(i-10,i):
#                 array.append(volt_equivalent_values[j])
#         array.append(volt_equivalent_values[i])
#     else:
        
#         if(len(array)>0): #in other words, checking that we have just been at a peak value
#             print(array)
#             for j in range(i,i+10):
#                 array.append(volt_equivalent_values[j])
#             array_of_arrays_of_period_hits_volt_equivalent.append(array)
#         array = []
#     # if(if_statement_triggered == False and not(volt_equivalent_values[i] < mean / 1.3)):
#     #     end_time = time_values[i]
#     #     time_interval = end_time - start_time
#     #     period_time_beginings.append(start_time)
#     #     period_time_intervals.append(time_values)



# print(mean,mean*2)
# print(len(array_of_arrays_of_period_hits_volt_equivalent))
# for array in array_of_arrays_of_period_hits_volt_equivalent:
#     print(gauss_fit_on_list(array))

# p1.plot(time_values, volt_equivalent_values)
# p1.scatter(period_points_time, period_points_volt_equivalent, color = "RED", linewidth=0.2)
# p1.show()


# # print(period_time_beginings)
# # print(period_time_intervals)



