
import serial
import matplotlib.pyplot as p1
import matplotlib.pyplot as plt
import numpy as np                # import numpy
from scipy import optimize
import random

# def gaus(x,A,x0,sigma):
#   temp = (x-x0)**2
#   temp = temp/(2*sigma**2)
#   return A * np.exp(-temp)

# def gauss_fit_on_list(LIST):
#     DataSet = LIST
#     max_value_in_data = 0
#     for i in DataSet:
#         if (i > max_value_in_data):
#             max_value_in_data = i
#     data = plt.hist(DataSet,bins=range(1,max_value_in_data+1,1),color='red',fill='red',alpha=.4)
#     bins = np.linspace(1,max_value_in_data,max_value_in_data)
#     # finds the median betwleen # 
#     bincenters = np.array([0.5 * (bins[i] + bins[i+1]) for i in range(len(bins)-1)])
#     parameters,  covariance = optimize.curve_fit(gaus,xdata=bincenters,ydata= data[0],p0=[6,6,1]) #covariance is only there because of python return
#     return parameters

time_values = []
print(serial.__version__)
#port = '/dev/cu.usbmodem14401'  # mac like port information
port = 'COM6' # windows like port information
ser = serial.Serial(port, 9600, timeout=1)

volt_equivalent_values = []
time_values = []
time_real = 0
max_volt_equivalent = 0
File_object = open(r"Lab8Data.txt", "w+")

while(time_real < 30000): #get 2.5 minutes worth of data
    message = ser.readline()     # read data from the serial port
    if(len(message) > 0):
        message = message.decode()   # decode here means convert from byte array to string
        message = message.strip()    # strip here means remove all whit charaters, new lines and carriage returns from the string.
        File_object.write(message + '\n')
        volt_equivalent,time,percent_turn_radius = message.split(':') # split the string at a colon, making two strings stored in time, value
        #time, percent_turn_radius = msg2.split(':')
        print(str(volt_equivalent) + ":::" + str(time) + ":::" + str(percent_turn_radius))  # print the first number
        time_real = int(time)
    #     time_values.append(int(time))
    #     volt_equivalent_values.append(int(volt_equivalent))
    #     if(int(volt_equivalent) > max_volt_equivalent):
    #         max_volt_equivalent = int(volt_equivalent)

File_object.close()